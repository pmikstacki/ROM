//! Test-support execution controls and scoped native read observations.
#[cfg(feature = "test-support")]
use rom::{Error, QueryBounds, QueryStrategy, StorageQuery};
use rom::{QueryRead, Result};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum QueryExecution {
    Automatic,
    #[cfg(feature = "test-support")]
    Reference,
    #[cfg(feature = "test-support")]
    Native,
}

#[cfg(feature = "test-support")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct QueryMetrics {
    pub strategy: QueryStrategy,
    /// Full stored Row JSON values decoded by the materialization statement.
    pub decoded_rows: usize,
    /// UTF-8 bytes submitted to the native Row JSON decoder, not heap allocation.
    pub decoded_bytes: usize,
    /// SQLite VM steps for materialization only, excluding metadata and EXPLAIN.
    pub vm_steps: u64,
}

#[derive(Debug)]
pub struct QueryObservation {
    pub read: QueryRead,
    #[cfg(feature = "test-support")]
    pub metrics: QueryMetrics,
}

#[cfg(feature = "test-support")]
impl crate::Sqlite {
    /// Measurement control only. Native bypasses cost comparison, never admission,
    /// semantic eligibility, snapshot binding or physical plan recognition. If no
    /// permitted native plan exists, metrics report the actual reference strategy.
    pub fn query_read_observed(
        &self,
        request: &StorageQuery,
        bounds: QueryBounds,
        execution: QueryExecution,
    ) -> Result<QueryObservation> {
        let mut connection = self.connection.lock().map_err(|_| Error::Panicked)?;
        let transaction = connection.transaction().map_err(|_| Error::Storage)?;
        crate::index::query_read_observed(&transaction, request, bounds, execution)
    }
}

pub(crate) fn observation(
    read: QueryRead,
    materialization: crate::read_rows::Metrics,
) -> Result<QueryObservation> {
    #[cfg(feature = "test-support")]
    let metrics = QueryMetrics {
        strategy: match &read {
            QueryRead::Reference { .. } => QueryStrategy::Reference,
            QueryRead::NativeCandidates { .. } => QueryStrategy::NativeCandidates,
        },
        decoded_rows: materialization.decoded_rows,
        decoded_bytes: materialization.decoded_bytes,
        vm_steps: materialization.vm_steps,
    };
    #[cfg(not(feature = "test-support"))]
    let _ = materialization;
    Ok(QueryObservation {
        read,
        #[cfg(feature = "test-support")]
        metrics,
    })
}

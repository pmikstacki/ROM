//! The native atomic Resource bundle and authoritative read interface.
use crate::{Sqlite, index, references};
use rom::{
    Bundle, Capabilities, Descriptor, Error, JournalCursor, JournalPage, Key, Receipt, Result, Row,
    Storage, StorageState, WorkRecord, WorkResult, WorkUpdate,
};
use rusqlite::{Connection, OptionalExtension, params};
#[cfg(feature = "test-support")]
use std::sync::atomic::Ordering;

pub(crate) fn row(c: &Connection, key: &Key) -> Result<Option<Row>> {
    Ok(row_with_length(c, key)?.map(|(row, _)| row))
}
fn row_with_length(c: &Connection, key: &Key) -> Result<Option<(Row, usize)>> {
    let text: Option<String> = c
        .query_row(
            "SELECT data FROM resources WHERE kind=? AND id=?",
            params![key.kind, key.id],
            |r| r.get(0),
        )
        .optional()
        .map_err(|_| Error::Storage)?;
    text.map(|t| {
        serde_json::from_str(&t)
            .map(|row| (row, t.len()))
            .map_err(|_| Error::Storage)
    })
    .transpose()
}
pub(crate) fn receipt(c: &Connection, id: &str) -> Result<Option<Receipt>> {
    let text: Option<String> = c
        .query_row("SELECT data FROM receipts WHERE identity=?", [id], |r| {
            r.get(0)
        })
        .optional()
        .map_err(|_| Error::Storage)?;
    text.map(|t| serde_json::from_str(&t).map_err(|_| Error::Storage))
        .transpose()
}
pub(crate) fn state(c: &Connection) -> Result<StorageState> {
    let text: String = c
        .query_row("SELECT data FROM rom_state WHERE id=1", [], |r| r.get(0))
        .map_err(|_| Error::Storage)?;
    serde_json::from_str(&text).map_err(|_| Error::Storage)
}
pub(crate) fn save_state(c: &Connection, state: &StorageState) -> Result<()> {
    c.execute(
        "UPDATE rom_state SET data=? WHERE id=1",
        [serde_json::to_string(state).map_err(|_| Error::Storage)?],
    )
    .map_err(|_| Error::NotCommitted)?;
    Ok(())
}
pub(crate) fn snapshot_rows(
    c: &Connection,
    kind: &str,
    max_rows: usize,
    max_bytes: usize,
) -> Result<Vec<Row>> {
    Ok(crate::read_rows::snapshot::<false>(c, kind, max_rows, max_bytes)?.0)
}
impl Storage for Sqlite {
    fn retry_epochs(&self) -> Result<rom::RetryEpochs> {
        Ok(state(&*self.connection.lock().map_err(|_| Error::Panicked)?)?.retry_epochs())
    }
    fn register(&self, descriptors: &[Descriptor]) -> Result<()> {
        let mut c = self.connection.lock().map_err(|_| Error::Panicked)?;
        let tx = c
            .transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)
            .map_err(|_| Error::Storage)?;
        references::register(&tx, descriptors)?;
        index::register(&tx, descriptors)?;
        tx.commit().map_err(|_| Error::Unknown)
    }
    fn supports_reactions(&self) -> bool {
        true
    }
    fn reaction_records(&self) -> Result<Vec<WorkRecord>> {
        Ok(
            state(&*self.connection.lock().map_err(|_| Error::Panicked)?)?
                .work
                .records(),
        )
    }
    fn reaction_update(&self, update: WorkUpdate) -> Result<WorkResult> {
        let mut c = self.connection.lock().map_err(|_| Error::Panicked)?;
        let tx = c
            .transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)
            .map_err(|_| Error::Storage)?;
        let mut s = state(&tx)?;
        let result = s.update_work(update)?;
        save_state(&tx, &s)?;
        tx.commit().map_err(|_| Error::Unknown)?;
        Ok(result)
    }
    fn supports_journal(&self) -> bool {
        true
    }
    fn journal_head(&self, kind: &str) -> Result<JournalCursor> {
        Ok(state(&*self.connection.lock().map_err(|_| Error::Panicked)?)?.journal_head(kind))
    }
    fn journal(
        &self,
        kind: &str,
        after: Option<&JournalCursor>,
        max_rows: usize,
        max_bytes: usize,
    ) -> Result<JournalPage> {
        state(&*self.connection.lock().map_err(|_| Error::Panicked)?)?
            .journal(kind, after, max_rows, max_bytes)
    }

    fn capabilities(&self) -> Capabilities {
        Capabilities {
            atomic_bundle: true,
            snapshots: true,
            effects: true,
        }
    }
    fn load(&self, key: &Key) -> Result<Option<Row>> {
        row(&self.connection.lock().unwrap(), key)
    }
    fn snapshot(&self, kind: &str, max_rows: usize, max_bytes: usize) -> Result<Vec<Row>> {
        let c = self.connection.lock().map_err(|_| Error::Panicked)?;
        snapshot_rows(&c, kind, max_rows, max_bytes)
    }
    fn query_read(
        &self,
        request: &rom::StorageQuery,
        bounds: rom::QueryBounds,
    ) -> Result<rom::QueryRead> {
        let mut c = self.connection.lock().map_err(|_| Error::Panicked)?;
        let tx = c.transaction().map_err(|_| Error::Storage)?;
        index::query_read(&tx, request, bounds)
    }
    fn receipt(&self, id: &str) -> Result<Option<Receipt>> {
        receipt(&self.connection.lock().unwrap(), id)
    }
    fn commit(&self, b: &Bundle) -> Result<Receipt> {
        let mut c = self.connection.lock().unwrap();
        let tx = c
            .transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)
            .map_err(|_| Error::Storage)?;
        let mut metadata = state(&tx)?;
        let prior = receipt(&tx, &b.receipt.identity)?;
        metadata.check_retry_epoch(
            b.receipt.retry_epoch,
            prior.is_some(),
            b.completed_work.as_ref().map(|(key, now)| (key, *now)),
        )?;
        if let Some(prior) = prior {
            metadata.check_retry_epoch(prior.retry_epoch, true, None)?;
            if prior.fingerprint != b.receipt.fingerprint
                || prior.retry_epoch != b.receipt.retry_epoch
            {
                return Err(Error::IdentityMismatch);
            }
            return Ok(prior);
        }
        let stored = row_with_length(&tx, &b.receipt.row.key)?;
        let old_raw_len = stored.as_ref().map(|(_, len)| *len);
        let existing = stored.map(|(row, _)| row);
        if existing.as_ref().map(|r| r.revision) != b.expected {
            return Err(Error::Conflict);
        }
        let expected_revision = b
            .expected
            .unwrap_or(0)
            .checked_add(u64::from(b.changed))
            .ok_or(Error::TooLarge)?;
        if b.receipt.row.revision != expected_revision
            || (!b.changed && (!b.effects.is_empty() || existing.as_ref() != Some(&b.receipt.row)))
        {
            return Err(Error::NotCommitted);
        }
        let targets = references::prepare(&tx, &b.receipt)?;
        let retired = metadata.bundle(b)?;
        #[cfg(feature = "test-support")]
        let f = self.fault.swap(0, Ordering::SeqCst);
        #[cfg(not(feature = "test-support"))]
        let f = 0;
        let mut ordinal = 0;
        if b.changed {
            let r = &b.receipt.row;
            tx.execute("INSERT INTO resources(kind,id,revision,data) VALUES (?,?,?,?) ON CONFLICT(kind,id) DO UPDATE SET revision=excluded.revision,data=excluded.data",params![r.key.kind,r.key.id,i64::try_from(r.revision).map_err(|_|Error::TooLarge)?,serde_json::to_string(r).unwrap()]).map_err(|_|Error::NotCommitted)?;
            ordinal += 1;
            self.checkpoint(ordinal).map_err(|_| Error::NotCommitted)?;
            references::replace(self, &tx, &r.key, &targets, &mut ordinal)?;
            index::replace(&tx, existing.as_ref(), r, old_raw_len, || {
                ordinal += 1;
                self.checkpoint(ordinal).map_err(|_| Error::NotCommitted)
            })?;
        }
        if f == 1 {
            return Err(Error::NotCommitted);
        }
        if b.changed {
            tx.execute(
                "INSERT INTO events(identity,data) VALUES (?,?)",
                params![
                    b.receipt.identity,
                    serde_json::to_string(&b.receipt.row).unwrap()
                ],
            )
            .map_err(|_| Error::NotCommitted)?;
            ordinal += 1;
            self.checkpoint(ordinal).map_err(|_| Error::NotCommitted)?;
        }
        if f == 2 {
            return Err(Error::NotCommitted);
        }
        tx.execute(
            "INSERT INTO receipts(identity,data) VALUES (?,?)",
            params![
                b.receipt.identity,
                serde_json::to_string(&b.receipt).unwrap()
            ],
        )
        .map_err(|_| Error::NotCommitted)?;
        ordinal += 1;
        self.checkpoint(ordinal).map_err(|_| Error::NotCommitted)?;
        if f == 3 {
            return Err(Error::NotCommitted);
        }
        for (i, intent) in b.effects.iter().enumerate() {
            tx.execute(
                "INSERT INTO effects(identity,ordinal,data) VALUES (?,?,?)",
                params![
                    b.receipt.identity,
                    i as i64,
                    serde_json::to_string(intent).unwrap()
                ],
            )
            .map_err(|_| Error::NotCommitted)?;
            ordinal += 1;
            self.checkpoint(ordinal).map_err(|_| Error::NotCommitted)?;
        }
        if f == 4 {
            return Err(Error::NotCommitted);
        }
        for id in retired {
            tx.execute("DELETE FROM events WHERE identity=?", [id])
                .map_err(|_| Error::NotCommitted)?;
            ordinal += 1;
            self.checkpoint(ordinal).map_err(|_| Error::NotCommitted)?;
        }
        save_state(&tx, &metadata)?;
        ordinal += 1;
        self.checkpoint(ordinal).map_err(|_| Error::NotCommitted)?;
        self.checkpoint(0).map_err(|_| Error::NotCommitted)?;
        tx.commit().map_err(|_| Error::Unknown)?;
        self.checkpoint(usize::MAX).map_err(|_| Error::Unknown)?;
        if f == 5 {
            Err(Error::Unknown)
        } else {
            Ok(b.receipt.clone())
        }
    }
}

import { test,expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
test('imports render and respond to input without browser errors',async({page})=>{
 const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
 await page.goto('./');await expect(page.getByRole('heading',{name:'ROM component compatibility trial'})).toBeVisible();
 await page.getByLabel('Resource name',{exact:true}).fill('Inventory');await expect(page.getByRole('cell',{name:'Inventory'})).toBeVisible();
 const counter=page.getByRole('button',{name:'Count 0'});await counter.focus();await page.keyboard.press('Enter');await expect(page.getByRole('button',{name:'Count 1'})).toBeVisible();
 await expect(page.getByRole('button',{name:'Unavailable'})).toBeDisabled();expect(errors).toEqual([]);
});
test('dialog traps focus, closes with Escape, and restores trigger focus',async({page})=>{
 await page.goto('./');const trigger=page.getByRole('button',{name:'Inspect resource'});await trigger.focus();await page.keyboard.press('Enter');
 const dialog=page.getByRole('dialog',{name:'Resource details'});await expect(dialog).toBeVisible();await expect(page.getByLabel('Dialog resource name')).toBeFocused();
 for(let i=0;i<8;i++){await page.keyboard.press('Tab');expect(await dialog.evaluate(el=>el.contains(document.activeElement))).toBe(true);}
 await page.keyboard.press('Escape');await expect(dialog).not.toBeVisible();await expect(trigger).toBeFocused();
});
test('assembled base and dialog have no axe A/AA violations',async({page})=>{
 await page.goto('./');let scan=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa']).analyze();expect(scan.violations).toEqual([]);
 await page.getByRole('button',{name:'Inspect resource'}).click();await expect(page.getByRole('dialog')).toBeVisible();scan=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa']).analyze();expect(scan.violations).toEqual([]);
});

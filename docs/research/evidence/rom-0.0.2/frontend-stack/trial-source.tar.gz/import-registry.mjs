import { mkdir,writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const hash = b => createHash('sha256').update(b).digest('hex');
const manifest = {date:new Date().toISOString(),style:'vega',source:'https://shadcn-svelte.com/registry/styles/vega',files:[],adaptations:['Replace $UTILS$ with $lib/utils and $UI$ with $lib/ui','Resolve upstream IconPlaceholder close icon to @lucide/svelte XIcon']};
for (const name of ['button','input','dialog','table','utils']) {
 const url=`${manifest.source}/${name}.json`;
 const response=await fetch(url);if(!response.ok)throw Error(`${url}: ${response.status}`);
 const raw=await response.text();await writeFile(`provenance/${name}.json`,raw);
 const item=JSON.parse(raw);manifest.files.push({registry:url,sha256:hash(raw),dependencies:item.dependencies,devDependencies:item.devDependencies});
 for(const file of item.files){
  const target=`src/lib/${name==='utils'?'':'ui/'}${file.target}`;
  let content=file.content.replaceAll('$UTILS$','$lib/utils').replaceAll('$UI$','$lib/ui');
  if(file.target.endsWith('dialog-content.svelte')) content=content.replace('import IconPlaceholder from "$lib/components/icon-placeholder/icon-placeholder.svelte";','import { XIcon } from "@lucide/svelte";').replace(/<IconPlaceholder[\s\S]*?\/>/,'<XIcon />');
  await mkdir(target.substring(0,target.lastIndexOf('/')),{recursive:true});await writeFile(target,content);
  manifest.files.push({target,upstreamContentSha256:hash(file.content),adaptedContentSha256:hash(content)});
 }
}
const licenseUrl='https://raw.githubusercontent.com/huntabyte/shadcn-svelte/main/LICENSE.md';
let r=await fetch(licenseUrl);if(!r.ok)throw Error(`license ${r.status}`);let license=await r.text();await writeFile('provenance/shadcn-LICENSE.md',license);manifest.license={url:licenseUrl,sha256:hash(license)};await writeFile('provenance/manifest.json',JSON.stringify(manifest,null,2)+'\n');

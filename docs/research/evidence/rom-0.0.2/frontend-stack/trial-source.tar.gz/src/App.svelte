<script lang="ts">
 import { Button } from '$lib/ui/button/index.js';
 import { Input } from '$lib/ui/input/index.js';
 import * as Dialog from '$lib/ui/dialog/index.js';
 import * as Table from '$lib/ui/table/index.js';
 let name=$state('Task'); let count=$state(0); let open=$state(false);
</script>
<main>
 <h1>ROM component compatibility trial</h1>
 <p>Imported shadcn components. This is not the Studio product.</p>
 <label for="resource-name">Resource name</label>
 <Input id="resource-name" bind:value={name} />
 <Button onclick={()=>count+=1}>Count {count}</Button>
 <Button disabled>Unavailable</Button>
 <Dialog.Root bind:open>
  <Dialog.Trigger>Inspect resource</Dialog.Trigger>
  <Dialog.Content>
   <Dialog.Header><Dialog.Title>Resource details</Dialog.Title><Dialog.Description>Inspect the current draft without committing it.</Dialog.Description></Dialog.Header>
   <label for="dialog-name">Dialog resource name</label><Input id="dialog-name" bind:value={name} />
   <Dialog.Footer><Dialog.Close>Done</Dialog.Close></Dialog.Footer>
  </Dialog.Content>
 </Dialog.Root>
 <Table.Root>
  <Table.Caption>Example Resource rows</Table.Caption>
  <Table.Header><Table.Row><Table.Head scope="col">Name</Table.Head><Table.Head scope="col">Count</Table.Head></Table.Row></Table.Header>
  <Table.Body><Table.Row><Table.Cell>{name}</Table.Cell><Table.Cell>{count}</Table.Cell></Table.Row></Table.Body>
 </Table.Root>
</main>

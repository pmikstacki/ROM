import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,cpSync} from 'node:fs';
import{createHash}from'node:crypto';
const root='/root/ROM/.worktrees/release-query-index';
const evidence=root+'/docs/research/evidence/rom-0.0.2/frontend-stack';
const commands=[['clean-install',['npm','ci','--ignore-scripts']],['typecheck',['npm','run','check']],['build',['npm','run','build']],['browser-chromium',['npm','test','--','--project=chromium']],['audit',['npm','audit','--json']]];
const results=[];
for(const [name,[program,...args]] of commands){let r=spawnSync(program,args,{encoding:'utf8',maxBuffer:16*1024*1024});writeFileSync(`${evidence}/verified-${name}.log`,r.stdout+r.stderr);results.push({name,command:[program,...args],exit:r.status,error:r.error?.message});if(r.status!==0){console.log(name,r.status);break;}}
const git=(...args)=>spawnSync('git',args,{cwd:root,encoding:'utf8'}).stdout.trim();
const hash=b=>createHash('sha256').update(b).digest('hex');
writeFileSync(`${evidence}/verification.json`,JSON.stringify({date:new Date().toISOString(),sourceCommit:git('rev-parse','HEAD'),sourceDirty:git('status','--short'),trialRoot:process.cwd(),node:process.version,npm:spawnSync('npm',['--version'],{encoding:'utf8'}).stdout.trim(),chromium:spawnSync('/root/.nix-profile/bin/chromium',['--version'],{encoding:'utf8'}).stdout.trim(),lockSha256:hash(readFileSync('package-lock.json')),results},null,2)+'\n');
for(const p of ['package.json','package-lock.json','provenance'])cpSync(p,`${evidence}/${p}`,{recursive:true});
if(results.length!==commands.length||results.some(r=>r.exit!==0))process.exitCode=1;
